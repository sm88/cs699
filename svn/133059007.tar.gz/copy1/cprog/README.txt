compile all files:
gcc -c main.cpp quickSort.cpp insertionSort.cpp

link:
gcc -o final main.o quickSort.o insertionSort.o

TODO:
will have to make a makefile soon!!!
