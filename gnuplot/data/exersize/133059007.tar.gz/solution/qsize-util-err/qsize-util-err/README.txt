anal-loss01-node1-stats.txt has data for packet loss of 1%
anal-loss05-node1-stats.txt has data for packet loss of 5%
anal-loss10-node1-stats.txt has data for packet loss of 10%
anal-loss20-node1-stats.txt has data for packet loss of 20%

Each file has:

Col-1: queue size
Col-2: queue utilization
Col-3: queue overflow percentage
Col-4: ignore this
